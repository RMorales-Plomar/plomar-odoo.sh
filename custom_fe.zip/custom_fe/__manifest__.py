# -*- coding: utf-8 -*- 

{
    'name': 'Custom Electronic Invoice GT',
    'version': '1.1.5',
    'license': "AGPL-3",
    'depends': [
        'account',
        'l10n_gt'
    ]
}
